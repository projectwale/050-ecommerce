/**
=========================================================
* E-commerce MUI - v3.0.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-material-ui
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

/** 
  All of the routes for the Soft UI Dashboard React are added here,
  You can add a new route, customize the routes and delete the routes here.
  Once you add a new route on this file it will be visible automatically on
  the Sidenav.
  For adding a new route you can follow the existing routes in the routes array.
  1. The `type` key with the `collapse` value is used for a route.
  2. The `type` key with the `title` value is used for a title inside the Sidenav. 
  3. The `type` key with the `divider` value is used for a divider between Sidenav items.
  4. The `name` key is used for the name of the route on the Sidenav.
  5. The `key` key is used for the key of the route (It will help you with the key prop inside a loop).
  6. The `icon` key is used for the icon of the route on the Sidenav, you have to add a node.
  7. The `collapse` key is used for making a collapsible item on the Sidenav that has other routes
  inside (nested routes), you need to pass the nested routes inside an array as a value for the `collapse` key.
  8. The `route` key is used to store the route location which is used for the react router.
  9. The `href` key is used to store the external links location.
  10. The `title` key is only for the item with the type of `title` and its used for the title text on the Sidenav.
  10. The `component` key is used to store the component of its route.
*/

// E-commerce MUI layouts
import Dashboard from "layouts/dashboard";
import Tables from "layouts/tables";
import Billing from "layouts/billing";
import VirtualReality from "layouts/virtual-reality";
import RTL from "layouts/rtl";
import Profile from "layouts/profile";
import Home from "layouts/userHome";
import UserCart from "layouts/userCart";
import AddProductUser from "layouts/addProductUser";
import EditProductUser from "layouts/editProductUser";
import EditProductUser1 from "layouts/editProductUser1";
import ShowOneProduct from "layouts/showOneProduct";
import SignIn from "layouts/authentication/sign-in";
import SignUp from "layouts/authentication/sign-up";
import AdminSignUp from "layouts/authentication/adminsign-in";
import Adminhome from "layouts/adminhome";
import EditProduct from "layouts/editProductadmin";
import ViewOrdersAdmin from "layouts/viewOrdersAdmin";
import EditProduct1 from "layouts/viewEditProduct";
import MyOrderUser from "layouts/MyOrderUser";
import ViewUsers from "layouts/viewUser";
import EditUser from "layouts/editUser";

import KnowCrop from "layouts/knowCrop";
import KnowFertilizer from "layouts/knowFertilizer";
import KnowDisease from "layouts/knowDisease";
import Graphs from "layouts/adminGraph";


// E-commerce MUI components
import ArgonBox from "components/ArgonBox";

const routes = [
  {
    type: "route",
    name: "Home",
    key: "Home",
    route: "/Home",
    icon: <ArgonBox component="i" color="primary" fontSize="16px" className="ni ni-app" />,
    component: <Home />,
  },
  {
    type: "route",
    name: "My orders",
    key: "vieworderuser",
    route: "/vieworderuser",
    icon: <ArgonBox component="i" color="primary" fontSize="15px" className="ni ni-shop" />,
    component: <MyOrderUser />,
  },
  // {
  //   type: "route",
  //   name: "Dashboard",
  //   key: "dashboard",
  //   route: "/dashboard",
  //   icon: <ArgonBox component="i" color="primary" fontSize="14px" className="ni ni-tv-2" />,
  //   component: <Dashboard />,
  // },
  {
    route: "/dashboard",
    component: <Dashboard />,
  },
  // {
  //   type: "route",
  //   name: "Tables",
  //   key: "tables",
  //   route: "/tables",
  //   icon: (
  //     <ArgonBox component="i" color="warning" fontSize="14px" className="ni ni-calendar-grid-58" />
  //   ),
  //   component: <Tables />,
  // },
  // {
  //   type: "route",
  //   name: "Billing",
  //   key: "billing",
  //   route: "/billing",
  //   icon: <ArgonBox component="i" color="success" fontSize="14px" className="ni ni-credit-card" />,
  //   component: <Billing />,
  // },
  // {
  //   type: "route",
  //   name: "Virtual Reality",
  //   key: "virtual-reality",
  //   route: "/virtual-reality",
  //   icon: <ArgonBox component="i" color="info" fontSize="14px" className="ni ni-app" />,
  //   component: <VirtualReality />,
  // },
  // {
  //   type: "route",
  //   name: "RTL",
  //   key: "rtl",
  //   route: "/rtl",
  //   icon: <ArgonBox component="i" color="error" fontSize="14px" className="ni ni-world-2" />,
  //   component: <RTL />,
  // },
  // { type: "title", title: "Account Pages", key: "account-pages" },
  // {
  //   type: "route",
  //   name: "Profile",
  //   key: "profile",
  //   route: "/profile",
  //   icon: <ArgonBox component="i" color="dark" fontSize="14px" className="ni ni-single-02" />,
  //   component: <Profile />,
  // },
  {
    type: "route",
    name: "Logout",
    key: "sign-in",
    route: "/authentication/sign-in",
    icon: (
      <ArgonBox component="i" color="warning" fontSize="14px" className="ni ni-single-copy-04" />
    ),
    component: <SignIn />,
  },
  // {
  //   type: "route",
  //   name: "Sign Up",
  //   key: "sign-up",
  //   route: "/authentication/sign-up",
  //   icon: <ArgonBox component="i" color="info" fontSize="14px" className="ni ni-collection" />,
  //   component: <SignUp />,
  // },
  {
    route: "/authentication/sign-up",
    component: <SignUp />,
  },

  {
    route: "/authentication/adminsign-up",
    component: <AdminSignUp />,
  },

  {
    route: "/adminDashboard",
    component: <Adminhome />,
  },

  {
    route: "/editProduct",
    component: <EditProduct />,
  },

  {
    route: "/viewUsers",
    component: <ViewUsers />,
  },

  {
    route: "/edit",
    component: <EditProduct1 />,
  },

  {
    route: "/editUser",
    component: <EditUser />,
  },

  {
    route: "/edit1",
    component: <EditProductUser1 />,
  },

  {
    route: "/showOneProduct",
    component: <ShowOneProduct />,
  },

  {
    route: "/userCart",
    component: <UserCart />,
  },

  {
    route: "/viewOrdersAdmin",
    component: <ViewOrdersAdmin />,
  },

  {
    route: "/Know-Crop",
    component: <KnowCrop />,
  },

  {
    route: "/Know-Fertilizer",
    component: <KnowFertilizer />,
  },

  {
    route: "/Know-Disease",
    component: <KnowDisease />,
  },  

  {
    route: "/Graphs",
    component: <Graphs />,
  },
];

export default routes;
