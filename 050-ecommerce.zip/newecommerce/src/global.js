export const ipofserver = 'http://192.168.0.105:5000/';
